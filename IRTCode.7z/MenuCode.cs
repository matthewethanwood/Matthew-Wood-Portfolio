using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.IO;
using System;
public class MenuCode : MonoBehaviour
{
    public TMP_InputField firstNameInputField;
    public TMP_InputField lastNameInputField;

    private string firstName;
    private string lastName;

    public void OnButtonClicked()
    { 
        firstName = firstNameInputField.text;
        lastName = lastNameInputField.text;

        PlayerPrefs.SetString("FirstName", firstName);
        PlayerPrefs.SetString("LastName", lastName);
    }

     public void CreateText()
    {
        // Get the path to the Documents directory
        string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

        // Specify the name of the folder
        string folderName = "Quiz Results";

        // Combine the Documents path with the folder name
        string folderPath = Path.Combine(documentsPath, folderName);

        // Check if the folder exists, and create it if it doesn't
        if (!Directory.Exists(folderPath))
        {
            Directory.CreateDirectory(folderPath);
        }

        // Create a text file within the folder
        string filePath = Path.Combine(folderPath, firstName + " " + lastName + ".txt");

        // Check if the file already exists (optional)
        if (!File.Exists(filePath))
        {
            // Create the text file
            using (StreamWriter writer = File.CreateText(filePath))
            {
                // You can write data to the file if needed
                writer.WriteLine("First Name: " + firstName);
                writer.WriteLine("Last Name: " + lastName + "\n");

                // Additional data writing can be done here
            }
        }
    }
}
