using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class PopUpQuestionManager : MonoBehaviour
{
    [SerializeField] GameObject popUpQuestion;

    public Button[] ratingOptions;
    public int rating;
    public void AskQuestion()
    {
        popUpQuestion.SetActive(true);
        Time.timeScale = 0;

        for (int i = 0; i < ratingOptions.Length; i++)
        {
            int index = i;
            ratingOptions[index].onClick.AddListener(() => RatingButtonPressed(index));
        }
    }

    public void QuestionRated()
    {
        popUpQuestion.SetActive(false);
        Time.timeScale = 1;
    }

    public void RatingButtonPressed(int buttonIndex)
    {
        rating = buttonIndex + 1;
        QuestionRated();
    }

    public int SetRating()
    {

        return rating;
    }

    private void UpdateText()
    {
        string firstName = PlayerPrefs.GetString("FirstName", "");
        string lastName = PlayerPrefs.GetString("LastName", "");

        string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

        // Specify the name of the folder
        string folderName = "Quiz Results";

        // Combine the Documents path with the folder name
        string folderPath = Path.Combine(documentsPath, folderName);

        string filePath = Path.Combine(folderPath, firstName + " " + lastName + ".txt");

        using (StreamWriter writer = File.AppendText(filePath))
        {
            writer.WriteLine("Students Current Engagement Level: " + rating);
        }
    }
}
