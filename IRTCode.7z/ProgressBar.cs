using System.Collections;
using System.Collections.Generic;
using TMPro.Examples;
using UnityEngine;
using UnityEngine.UI;

public class ProgressBar : MonoBehaviour
{
    [SerializeField] private Image bar_fill;

    [SerializeField] private Color color;

    private float currentAmount = 0;

    private Coroutine routine;

    private void OnEnable()
    {
        InitColor();
        currentAmount = 0;
        bar_fill.fillAmount = currentAmount;
    }

    void InitColor()
    {
        bar_fill.color = color;
    }

    public void UpdateProgress (float amount, float duration = 0.1f)
    {
        if (routine != null)
            StopCoroutine(routine);

        float target = currentAmount + amount;
        routine = StartCoroutine(FillRoutine(target, duration));
    }

    private IEnumerator FillRoutine(float target, float duration)
    {
        float time = 0;
        float tempAmount = currentAmount;
        float diff = target - tempAmount;
        currentAmount = target;

        while (time < duration)
        {
            time += Time.deltaTime;
            float percent = time / duration;
            bar_fill.fillAmount = tempAmount + diff * percent;
            yield return null;
        }

    }
}
