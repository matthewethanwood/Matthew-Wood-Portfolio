using Newtonsoft.Json.Bson;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProgressButton : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField] ProgressBar bar;

    public void Progress()
    {
        bar.UpdateProgress(0.067f);
    }
}
