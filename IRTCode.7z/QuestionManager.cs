using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using TMPro;
using System.IO;
using System;
using System.Threading;

public class QuestionManager : MonoBehaviour
{
    public TextMeshProUGUI questionText;
    public Button[] optionButtons;
    public TextMeshProUGUI sQuestionText;
    public TextMeshProUGUI scoreText;
    public Button quitButton;
    [SerializeField] GameObject popUpQuestion;

    public Button[] ratingOptions;

    private List<MathQuestion> questions;
    private List<SurveyQuestion> sQuestions;
    private SurveyQuestion currentSQuestion;
    private float timer;
    private bool timerRunning = false;
    private int correctAnswers = 0;
    private int sAnswers = 0;
    private bool correctness = false;
    private float ability = 0.54f;
    private int questionsAnswered = 0;
    private MathQuestion currentQuestion;
    private string rating;


    private void Start()
    {
        questions = GetComponent<Questions>().mathQuestions; // Reference to your Questions script
        sQuestions = GetComponent<SQuestions>().surveyQuestions;
        currentSQuestion = sQuestions[sAnswers];
        ability = 0.54f;
        scoreText.alpha = 0f;
        foreach (MathQuestion question in questions)
        {
            if (ability <= question.difficulty)
            {
                currentQuestion = question;
                break;
            }
        }
        DisplayQuestion(currentQuestion);
    }

    private void Update()
    {
        if (timerRunning)
        {
            timer += Time.deltaTime;
        }
    }

    public void AnswerQuestion(int selectedOption)
    {
        if (selectedOption == currentQuestion.correctOption)
        {
            Debug.Log("Correct");
            Debug.Log("Time it took to answer " + timer.ToString("0.##"));
            correctAnswers++;
            ability += currentQuestion.learningRate;
            correctness = true;
        }
        else
        {
            Debug.Log("Incorrect");
            Debug.Log("Time it took to answer " + timer.ToString("0.##"));
            ability -= currentQuestion.learningRate;
            correctness = false;
        }
        Debug.Log("Ability is at " + ability);

        UpdateText(currentQuestion, selectedOption, correctness, timer);
        questions.Remove(currentQuestion);

        ability = Mathf.Clamp(ability, 0f, 1f);

        questionsAnswered++;

        if (questionsAnswered % 4 == 0 && sAnswers < 3)
        {
            AskQuestion(currentSQuestion);
        }


        else if (questionsAnswered < 15)
        {
            MathQuestion nextQuestion = SelectNextQuestion();

            if(nextQuestion != null)
            {
                currentQuestion = nextQuestion;
                DisplayQuestion(currentQuestion);
            }
            else
            {
                EndQuiz();
            }
        }
        else
        {
            EndQuiz();
        }
    }

    private void EndQuiz()
    {
        Debug.Log("Quiz Completed");
        string firstName = PlayerPrefs.GetString("FirstName", "");
        string lastName = PlayerPrefs.GetString("LastName", "");

        string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

        // Specify the name of the folder
        string folderName = "Quiz Results";

        // Combine the Documents path with the folder name
        string folderPath = Path.Combine(documentsPath, folderName);

        string filePath = Path.Combine(folderPath, firstName + " " + lastName + ".txt");

        timerRunning = false;
        foreach(Button option in optionButtons)
        {
            option.gameObject.SetActive(false);
        }
        quitButton.gameObject.SetActive(true);
        DisplayScore();

        using (StreamWriter writer = File.AppendText(filePath))
        {
            writer.WriteLine("Score: " + correctAnswers);
        }
    }

    private MathQuestion SelectNextQuestion()
    {
        MathQuestion closestQuestion = null;
        float closestDifference = float.MaxValue;
        foreach (MathQuestion question in questions)
        {
            float difficulty = question.difficulty;
            float discrimination = question.discrimination;
            float guessing = question.guessing;

            // Calculate the 3PL probability of correct response
            float pCorrect = (guessing + (1 - guessing)) * (1 / (1 + Mathf.Exp(-discrimination * (ability - difficulty))));

            float difference = Mathf.Abs(pCorrect - 0.5f);

            if (difference < closestDifference)
            {
                closestQuestion = question;
                closestDifference = difference;
            }
       }
       return closestQuestion;
    }


    private void DisplayQuestion(MathQuestion question)
    {
        questionText.text = question.question;

        for (int i = 0; i < optionButtons.Length; i++)
        {
            TextMeshProUGUI buttonText = optionButtons[i].GetComponentInChildren<TextMeshProUGUI>();
            buttonText.text = question.options[i];
            int index = i; // Capture the current value of i

            // Attach a click listener to the button and pass the selected option index
            optionButtons[i].onClick.RemoveAllListeners();
            optionButtons[i].onClick.AddListener(() => AnswerQuestion(index));
        }


        timer = 0; // Reset the timer
        timerRunning = true;
    }
    public void AskQuestion(SurveyQuestion question)
    {
        sQuestionText.text = question.question;
        popUpQuestion.SetActive(true);
        Time.timeScale = 0;

        for (int i = 0; i < ratingOptions.Length; i++)
        {
            TextMeshProUGUI ratingText = ratingOptions[i].GetComponentInChildren<TextMeshProUGUI>();
            ratingText.text = question.answer[i];
            int index = i;

            ratingOptions[i].onClick.RemoveAllListeners();
            ratingOptions[i].onClick.AddListener(() => RatingButtonPressed(index));
        }
    }

    public void QuestionRated()
    {
        if(sAnswers < 2)
        {
            sAnswers += 1;
            currentSQuestion = sQuestions[sAnswers];
        }
        else
        {
            sAnswers = 4;
        }
        UpdateRating();
        if (questionsAnswered < 15)
        {
            MathQuestion nextQuestion = SelectNextQuestion();

            if(nextQuestion != null)
            {
                currentQuestion = nextQuestion;
                DisplayQuestion(currentQuestion);
            }
            else
            {
                EndQuiz();
            }
        }
        else
        {
            EndQuiz();
        }
        popUpQuestion.SetActive(false);
        Time.timeScale = 1;
    }

    public void RatingButtonPressed(int answer)
    {
        rating = currentSQuestion.answer[answer];
        QuestionRated();
    }

    private void DisplayScore()
    {
        scoreText.alpha = 1f;
        scoreText.text = "Correct Answers: " + correctAnswers.ToString();
    }
    
    private void UpdateText(MathQuestion currentQuesiton, int chosenOption, bool correctness, float time)
    {
        string firstName = PlayerPrefs.GetString("FirstName", "");
        string lastName = PlayerPrefs.GetString("LastName", "");

        string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

        // Specify the name of the folder
        string folderName = "Quiz Results";

        // Combine the Documents path with the folder name
        string folderPath = Path.Combine(documentsPath, folderName);

        string filePath = Path.Combine(folderPath, firstName + " " + lastName + ".txt");

        using (StreamWriter writer = File.AppendText(filePath))
        {
            writer.WriteLine("Question: " + currentQuesiton.question);
            writer.WriteLine("Answer given: " + currentQuesiton.options[chosenOption]);
            if (correctness == true)
            {
                writer.WriteLine("Correctness: Correct");
            }
            else
            {
                writer.WriteLine("Correctness: Incorrect");
            }
            writer.WriteLine("Time it took to answer: " + timer.ToString("0.##") + " seconds\n");
        }
    }

    private void UpdateRating()
    {
        string firstName = PlayerPrefs.GetString("FirstName", "");
        string lastName = PlayerPrefs.GetString("LastName", "");

        string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

        // Specify the name of the folder
        string folderName = "Quiz Results";

        // Combine the Documents path with the folder name
        string folderPath = Path.Combine(documentsPath, folderName);

        string filePath = Path.Combine(folderPath, firstName + " " + lastName + ".txt");

        using (StreamWriter writer = File.AppendText(filePath))
        {
            writer.WriteLine("\n" + rating + "\n\n");
        }
    }
}

