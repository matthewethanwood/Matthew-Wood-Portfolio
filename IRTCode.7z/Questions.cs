﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using Unity.VisualScripting;

[System.Serializable]
public class MathQuestion
{
    public string question;
    public string[] options;
    public int correctOption;
    public float difficulty;
    public float discrimination;
    public float guessing;
    public float timer;
    public float learningRate;
}

public class Questions : MonoBehaviour
{
    public List<MathQuestion> mathQuestions = new List<MathQuestion>
    {
        new MathQuestion
        {
            question = "What is the result when you divide any number by itself?",
            options = new string[] { "0", "1", "2", "Undefined" },
            correctOption = 1,
            difficulty = 0.13f,
            discrimination = 0.29f,
            guessing = 0.15f,
            timer = 7,
            learningRate = 0.05f,
        },
        new MathQuestion
        {
            question = "What is the result when you multiply any number by 0?",
            options = new string[] { "0", "1", "2", "Undefined" },
            correctOption = 0,
            difficulty = 0.16f,
            discrimination = 0.19f,
            guessing = 0.10f,
            timer = 7,
            learningRate = 0.05f,
        },
        new MathQuestion
        {
            question = "What is the result when you subtract any number from itself?",
            options = new string[] { "-1", "0", "1", "2" },
            correctOption = 1,
            difficulty = 0.19f,
            discrimination = 0.38f,
            guessing = 0.15f,
            timer = 7,
            learningRate = 0.05f,
        },
        new MathQuestion
        {
            question = "When you multiply a fraction by its reciprocal, what is the outcome?",
            options = new string[] { "0", "1", "2", "undefined" },
            correctOption = 1,
            difficulty = 0.23f,
            discrimination = 0.57f,
            guessing = 0.24f,
            timer = 9,
            learningRate = 0.1f,
        },
        new MathQuestion
        {
            question = "When dividing fractions, what operation do you change it to?",
            options = new string[] { "Addition", "Subtraction", "Division", "Multiplication" },
            correctOption = 3,
            difficulty = 0.26f,
            discrimination = 0.24f,
            guessing = 0.10f,
            timer = 9,
            learningRate = 0.1f,
        },
        new MathQuestion
        {
            question = "Which is equivalent to ½?",
            options = new string[] { "4/8", "4/10", "8/10", "6/9" },
            correctOption = 0,
            difficulty = 0.29f,
            discrimination = 0.19f,
            guessing = 0.24f,
            timer = 9,
            learningRate = 0.1f,
        },
        new MathQuestion
        {
            question = "Solve the expression: 3 × (4 + 2) - 5 = __",
            options = new string[] { "9", "13", "33", "63" },
            correctOption = 1,
            difficulty = 0.33f,
            discrimination = 0.34f,
            guessing = 0.15f,
            timer = 11,
            learningRate = 0.15f,
        },
        new MathQuestion
        {
            question = "Solve the expression: 8 - (9 / 3) + 4 = __",
            options = new string[] { "4", "-9", "9", "-4" },
            correctOption = 2,
            difficulty = 0.36f,
            discrimination = 0.57f,
            guessing = 0.10f,
            timer = 11,
            learningRate = 0.15f,
        },
        new MathQuestion
        {
            question = "Solve the expression: 5 × (3 - 2) + 4 = __",
            options = new string[] { "9", "13", "17", "21" },
            correctOption = 0,
            difficulty = 0.39f,
            discrimination = 0.38f,
            guessing = 0.10f,
            timer = 11,
            learningRate = 0.15f,
        },
        new MathQuestion
        {
            question = "Subtract 9.2 from 26.1",
            options = new string[] { "18.2", "17.9", "17.1", "16.9" },
            correctOption = 3,
            difficulty = 0.43f,
            discrimination = 0.72f,
            guessing = 0.24f,
            timer = 13,
            learningRate = 0.2f,
        },
        new MathQuestion
        {
            question = "Add 17.7 to 7.6",
            options = new string[] { "24.3", "24.4", "25.3", "25.5" },
            correctOption = 2,
            difficulty = 0.46f,
            discrimination = 0.24f,
            guessing = 0.19f,
            timer = 13,
            learningRate = 0.2f,
        },
        new MathQuestion
        {
            question = "Subtract 13.4 from 27.7",
            options = new string[] { "14.3", "16.4", "24.3", "27.6" },
            correctOption = 0,
            difficulty = 0.49f,
            discrimination = 0.34f,
            guessing = 0.19f,
            timer = 13,
            learningRate = 0.2f,
        },
        new MathQuestion
        {
            question = "What is the product of 0.022 and 10?",
            options = new string[] { "2.20", "0.22", "0.0022", "0.2" },
            correctOption = 1,
            difficulty = 0.53f,
            discrimination = 0.57f,
            guessing = 0.24f,
            timer = 15,
            learningRate = 0.25f,
        },
        new MathQuestion
        {
            question = "What is the quotient of 10.5 divided by 1.5?",
            options = new string[] { "18", "15", "6.5", "7" },
            correctOption = 3,
            difficulty = 0.56f,
            discrimination = 0.72f,
            guessing = 0.15f,
            timer = 15,
            learningRate = 0.25f,
        },
        new MathQuestion
        {
            question = "What is the quotient of 44 divided by 0.1?",
            options = new string[] { "4.4", "44", "440", "4400" },
            correctOption = 2,
            difficulty = 0.59f,
            discrimination = 0.95f,
            guessing = 0.10f,
            timer = 15,
            learningRate = 0.25f,
        },
        new MathQuestion
        {
            question = "Convert 1¾ to an improper fraction.",
            options = new string[] { "3/4", "7/4", "4/7", "4/3" },
            correctOption = 1,
            difficulty = 0.63f,
            discrimination = 0.34f,
            guessing = 0.24f,
            timer = 17,
            learningRate = 0.3f,
        },
        new MathQuestion
        {
            question = "Convert 2⅓ to an improper fraction.",
            options = new string[] { "7/3", "2/3", "1/2", "1/3" },
            correctOption = 0,
            difficulty = 0.66f,
            discrimination = 0.38f,
            guessing = 0.15f,
            timer = 17,
            learningRate = 0.3f,
        },
        new MathQuestion
        {
            question = "Convert 5 2/5 to an improper fraction.",
            options = new string[] { "5/27", "27/5", "5/2", "2/5" },
            correctOption = 1,
            difficulty = 0.69f,
            discrimination = 0.38f,
            guessing = 0.24f,
            timer = 17,
            learningRate = 0.3f,
        },
        new MathQuestion
        {
            question = "Calculate the GCF of 18 and 27.",
            options = new string[] { "1", "3", "6", "9" },
            correctOption = 3,
            difficulty = 0.73f,
            discrimination = 0.48f,
            guessing = 0.24f,
            timer = 19,
            learningRate = 0.35f,
        },

        //continue here
        new MathQuestion
        {
            question = "Determine the LCD of 10 and 12.",
            options = new string[] { "30", "40", "60", "70" },
            correctOption = 2,
            difficulty = 0.76f,
            discrimination = 0.53f,
            guessing = 0.10f,
            timer = 19,
            learningRate = 0.35f,
        },
        new MathQuestion
        {
            question = "Find the GCF of 24 and 36.",
            options = new string[] { "12", "8", "4", "2" },
            correctOption = 0,
            difficulty = 0.79f,
            discrimination = 0.53f,
            guessing = 0.19f,
            timer = 19,
            learningRate = 0.35f,
        },
        new MathQuestion
        {
            question = "If a rectangle has a length of 8 cm and a width of 5 cm, what is its area?",
            options = new string[] { "10cm²", "20cm²", "30cm²", "40cm²" },
            correctOption = 1,
            difficulty = 0.83f,
            discrimination = 0.67f,
            guessing = 0.19f,
            timer = 21,
            learningRate = 0.4f,
        },
        new MathQuestion
        {
            question = "If a square has an area of 49 cm², what is the length of one side?",
            options = new string[] { "7cm", "9cm", "12cm", "16cm" },
            correctOption = 0,
            difficulty = 0.86f,
            discrimination = 0.48f,
            guessing = 0.43f,
            timer = 21,
            learningRate = 0.4f,
        },
        new MathQuestion
        {
            question = "What is the perimeter of a rectangle with length 8 cm and width 5 cm?",
            options = new string[] { "18cm", "26cm", "40cm", "13cm" },
            correctOption = 1,
            difficulty = 0.89f,
            discrimination = 0.86f,
            guessing = 0.19f,
            timer = 21,
            learningRate = 0.4f,
        },
        new MathQuestion
        {
            question = "If a rectangle has a length-to-width ratio of 5:2, and the width is 8 meters, what is the length of the rectangle?",
            options = new string[] { "1", "2", "3", "4" },
            correctOption = 3,
            difficulty = 0.92f,
            discrimination = 0.72f,
            guessing = 0.29f,
            timer = 23,
            learningRate = 0.45f,
        },
        new MathQuestion
        {
            question = "If the scale factor between two similar triangles is 1:3, and the smaller triangle has a side length of 6cm, what is the corresponding side length of the larger triangle?",
            options = new string[] { "6cm", "24cm", "18cm", "12cm" },
            correctOption = 2,
            difficulty = 0.93f,
            discrimination = 0.57f,
            guessing = 0.29f,
            timer = 23,
            learningRate = 0.45f,
        },
        new MathQuestion
        {
            question = "If there are 12 boys and 8 girls in a class, what is the ratio of boys to girls?",
            options = new string[] { "3:2", "2:3", "6:5", "5:6" },
            correctOption = 0,
            difficulty = 0.94f,
            discrimination = 0.43f,
            guessing = 0.10f,
            timer = 23,
            learningRate = 0.45f,
        },
        new MathQuestion
        {
            question = "A sequence starts with 2 and follows the rule: each term is triple the previous term. Determine the 3rd term.",
            options = new string[] { "6", "12", "18", "24" },
            correctOption = 2,
            difficulty = 0.96f,
            discrimination = 0.76f,
            guessing = 0.19f,
            timer = 25,
            learningRate = 0.5f,
        },
        new MathQuestion
        {
            question = "Starting with 32, a sequence follows the rule: each term is half of the previous term. Determine the 4th term.",
            options = new string[] { "1", "2", "3", "4" },
            correctOption = 3,
            difficulty = 0.98f,
            discrimination = 0.62f,
            guessing = 0.34f,
            timer = 25,
            learningRate = 0.5f,
        },
        new MathQuestion
        {
            question = "A sequence starts with 3 and follows the rule: each term is double the previous term. Find the 5th term.",
            options = new string[] { "24", "48", "96", "192" },
            correctOption = 1,
            difficulty = 1.0f,
            discrimination = 0.57f,
            guessing = 0.19f,
            timer = 25,
            learningRate = 0.5f,
        },

    };

}
