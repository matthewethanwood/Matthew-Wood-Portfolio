using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using Unity.VisualScripting;

[System.Serializable]

public class SurveyQuestion
{
    public string question;
    public string[] answer;
}

public class SQuestions : MonoBehaviour
{
    public List<SurveyQuestion> surveyQuestions = new List<SurveyQuestion>
    {
        new SurveyQuestion
        {
            question = "Do you feel bored right now?",
            answer = new string[] { "Not at all", "A little", "Somewhat", "A lot", "Very Much"}
        },
        new SurveyQuestion
        {
            question = "How hard are you concentrating right now?",
            answer = new string[] { "Not at all", "A little", "Somewhat", "A lot", "Very Much"}
        },
        new SurveyQuestion
        {
            question = "Do you find the game to be enjoyable?",
            answer = new string[] { "Not at all", "A little", "Somewhat", "A lot", "Very Much"}
        },
    };
}